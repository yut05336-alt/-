# VM-2500 Android用パッケージ

## 方法1: Android端末でそのまま使う（APKビルド不要・完全オフライン）
1. このZIPファイルをAndroid端末で展開（解凍）します。
2. `index.html` を Chrome などのブラウザで開きます。
3. メニューの「ホーム画面に追加」を選ぶと、スマホアプリのようにすぐ起動して使えます。

## 方法2: Android Studio で APK をビルドする
1. Android Studio で `android-studio-project` フォルダを開きます。
2. `AndroidManifest.xml` には `INTERNET` 権限を含めていないため、OSレベルでもインターネット通信を行いません。
3. メニューの **Build > Build Bundle(s) / APK(s) > Build APK(s)** で `.apk` を生成し、Android端末へインストールできます。
